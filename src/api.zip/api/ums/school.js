import request from '@/utils/request'
export function fetchList(params) {
    return request({
        url:'/t/school/list',
        method:'get',
        params:params
    })
}
export function createSchool(data) {
    return request({
        url:'/t/school/create',
        method:'post',
        data:data
    })
}

export function deleteSchool(id) {
    return request({
        url:'/t/school/delete/'+id,
        method:'get',
    })
}

export function getSchool(id) {
    return request({
        url:'/t/school/'+id,
        method:'get',
    })
}

export function updateSchool(id,data) {
    return request({
        url:'/t/school/update/'+id,
        method:'post',
        data:data
    })
}

