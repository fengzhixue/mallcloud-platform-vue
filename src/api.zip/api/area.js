import request from '@/utils/request'
export function fetchList(params) {
    return request({
        url:'/t/area/list',
        method:'get',
        params:params
    })
}
export function createArea(data) {
    return request({
        url:'/t/area/create',
        method:'post',
        data:data
    })
}

export function deleteArea(id) {
    return request({
        url:'/t/area/delete/'+id,
        method:'get',
    })
}

export function getArea(id) {
    return request({
        url:'/t/area/'+id,
        method:'get',
    })
}

export function updateArea(id,data) {
    return request({
        url:'/t/area/update/'+id,
        method:'post',
        data:data
    })
}

