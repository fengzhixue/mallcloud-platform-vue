import request from '@/utils/request'
export function fetchList(params) {
    return request({
        url:'/sms/redPacket/list',
        method:'get',
        params:params
    })
}
export function createRedPacket(data) {
    return request({
        url:'/sms/redPacket/create',
        method:'post',
        data:data
    })
}

export function deleteRedPacket(id) {
    return request({
        url:'/sms/redPacket/delete/'+id,
        method:'get',
    })
}

export function getRedPacket(id) {
    return request({
        url:'/sms/redPacket/'+id,
        method:'get',
    })
}

export function updateRedPacket(id,data) {
    return request({
        url:'/sms/redPacket/update/'+id,
        method:'post',
        data:data
    })
}

