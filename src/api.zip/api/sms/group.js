import request from '@/utils/request'
export function fetchList(params) {
    return request({
        url:'/sms/group/list',
        method:'get',
        params:params
    })
}

export function listGroupMember(params) {
  return request({
    url:'/sms/group/listGroupMember',
    method:'get',
    params:params
  })
}
export function createGroup(data) {
    return request({
        url:'/sms/group/create',
        method:'post',
        data:data
    })
}

export function deleteGroup(id) {
    return request({
        url:'/sms/group/delete/'+id,
        method:'get',
    })
}

export function getGroup(id) {
    return request({
        url:'/sms/group/'+id,
        method:'get',
    })
}

export function updateGroup(id,data) {
    return request({
        url:'/sms/group/update/'+id,
        method:'post',
        data:data
    })
}

